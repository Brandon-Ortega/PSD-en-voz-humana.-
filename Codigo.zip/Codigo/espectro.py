import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import welch
import librosa

# Configuración del directorio donde están los audios
audio_dir = r'C:\Users\mmmmm\Documents\Espectro_pot_Fr\dataset'  # Cambia la ruta
audio_files = [f for f in os.listdir(audio_dir) if f.endswith('.wav')]

# Parámetros para el método de Welch
window = 256
noverlap = 128
nfft = 512

# Función para calcular la frecuencia acumulada correspondiente a un porcentaje de la potencia total
def frecuencia_acumulada(f, Pxx, porcentaje):
    potencia_total = np.sum(Pxx)
    potencia_acumulada = np.cumsum(Pxx) / potencia_total
    idx = np.where(potencia_acumulada >= porcentaje)[0][0]  # Obtener el índice de la frecuencia acumulada
    return f[idx]

# Función para calcular la potencia acumulada en un rango de frecuencias
def potencia_acumulada_en_rango(f, Pxx, f_max):
    idx = np.where(f <= f_max)[0]
    potencia = np.sum(Pxx[idx])
    potencia_total = np.sum(Pxx)
    return potencia / potencia_total * 100  # Retorna el porcentaje de la potencia total

# Listas para almacenar las PSD y las frecuencias
psd_total = []
frequencies = None

# Variables para promediar los resultados estadísticos
f_50_total = 0
f_70_total = 0
f_90_total = 0
potencia_4khz_total = 0
potencia_3_4khz_total = 0

# Contador de audios procesados
num_audios = len(audio_files)

# Iterar sobre todos los archivos de audio
for audio_file in audio_files:
    # Cargar el archivo de audio
    audio_path = os.path.join(audio_dir, audio_file)
    audio_data, fs = librosa.load(audio_path, sr=None)  # sr=None para mantener la frecuencia original

    # Verificar si el archivo está vacío o tiene solo silencio
    if np.all(audio_data == 0):
        print(f"El archivo {audio_file} contiene solo silencio.")
        continue

    # Normalizar el audio
    audio_data = librosa.util.normalize(audio_data)

    # Calcular la densidad espectral de potencia (PSD) utilizando el método de Welch
    f, Pxx = welch(audio_data, fs, nperseg=min(window, len(audio_data)), noverlap=noverlap, nfft=nfft)

    # Almacenar las PSD y las frecuencias
    if frequencies is None:
        frequencies = f
    psd_total.append(Pxx)

    # Análisis de potencia acumulada
    f_50 = frecuencia_acumulada(f, Pxx, 0.50)  # Frecuencia donde se acumula el 50% de la potencia
    f_70 = frecuencia_acumulada(f, Pxx, 0.70)  # Frecuencia donde se acumula el 70% de la potencia
    f_90 = frecuencia_acumulada(f, Pxx, 0.90)  # Frecuencia donde se acumula el 90% de la potencia

    potencia_4khz = potencia_acumulada_en_rango(f, Pxx, 4000)  # Potencia acumulada hasta 4 kHz
    potencia_3_4khz = potencia_acumulada_en_rango(f, Pxx, 3400)  # Potencia acumulada hasta 3.4 kHz

    # Sumar los resultados para promediar al final
    f_50_total += f_50
    f_70_total += f_70
    f_90_total += f_90
    potencia_4khz_total += potencia_4khz
    potencia_3_4khz_total += potencia_3_4khz

    # Imprimir los resultados individuales
    print(f'Archivo: {audio_file}')
    print(f'Frecuencia acumulada 50%: {f_50:.2f} Hz')
    print(f'Frecuencia acumulada 70%: {f_70:.2f} Hz')
    print(f'Frecuencia acumulada 90%: {f_90:.2f} Hz')
    print(f'Potencia acumulada hasta 4 kHz: {potencia_4khz:.2f}%')
    print(f'Potencia acumulada hasta 3.4 kHz: {potencia_3_4khz:.2f}%\n')

# Calcular el promedio de las PSD
psd_avg = np.mean(psd_total, axis=0)

# Calcular el promedio de los resultados estadísticos
f_50_promedio = f_50_total / num_audios
f_70_promedio = f_70_total / num_audios
f_90_promedio = f_90_total / num_audios
potencia_4khz_promedio = potencia_4khz_total / num_audios
potencia_3_4khz_promedio = potencia_3_4khz_total / num_audios

# Imprimir el promedio de los resultados estadísticos
print(f'Promedio de la frecuencia acumulada 50%: {f_50_promedio:.2f} Hz')
print(f'Promedio de la frecuencia acumulada 70%: {f_70_promedio:.2f} Hz')
print(f'Promedio de la frecuencia acumulada 90%: {f_90_promedio:.2f} Hz')
print(f'Promedio de la potencia acumulada hasta 4 kHz: {potencia_4khz_promedio:.2f}%')
print(f'Promedio de la potencia acumulada hasta 3.4 kHz: {potencia_3_4khz_promedio:.2f}%\n')

# Graficar la PSD promedio
plt.figure()
plt.semilogy(frequencies, psd_avg)
plt.xlim([0, 5000])  # Limitar el rango de frecuencias a 0-5 kHz
plt.title('Densidad espectral de potencia promedio')
plt.xlabel('Frecuencia (Hz)')
plt.ylabel('Densidad espectral de potencia (potencia/Hz)')
plt.grid(True)
plt.show()
